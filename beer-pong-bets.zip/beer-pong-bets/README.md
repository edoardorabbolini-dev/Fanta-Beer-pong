# 🍺 Beer Pong Bets

App di scommesse per un torneo di beer pong. Le partite si creano al momento, le quote si aggiornano
dopo ogni risultato e tutti i dispositivi vedono scommesse e classifica in tempo reale.

Pagina statica (HTML, CSS, JavaScript) con database Firebase Firestore. Nessun build, nessuna dipendenza da installare.

## Come funziona

- **Partite:** scegli due squadre, crea la partita, tocca la quota per scommettere. "Ha vinto" chiude la partita e paga.
- **Vincitore:** quote sul vincitore del torneo. Chi perde una partita è fuori. "Campioni" chiude le scommesse finali.
- **Classifica:** saldo di ogni scommettitore e storico delle schedine.
- **Setup:** aggiungi gli scommettitori (partono con 100 gettoni) e azzera tutto.
- **Quote:** calcolate con un punteggio Elo per squadra (parte da 1000, cambia a ogni partita), con un margine del 7%.
- **Saldi:** calcolati dalle scommesse registrate, così più persone possono scommettere insieme senza sovrascriversi.

## Installazione

### 1. Crea il database Firebase
1. Vai su [console.firebase.google.com](https://console.firebase.google.com) e crea un progetto (Analytics non serve).
2. Build > Firestore Database > Crea database, sede in Europa, modalità test.
3. Scheda Regole: incolla il contenuto di `firestore.rules` e pubblica.
4. Impostazioni progetto > Le tue app > `</>` (Web): registra l'app e copia `firebaseConfig`.

### 2. Configura l'app
Incolla i valori in `firebase-config.js` al posto di `INCOLLA_QUI`.

### 3. Pubblica con GitHub Pages
1. Carica il progetto su un repository GitHub.
2. Settings > Pages > Source: **Deploy from a branch**, branch `main`, cartella `/ (root)`.
3. Dopo un minuto il sito è su `https://<tuo-utente>.github.io/<nome-repo>/`. Condividi quel link.

Per provarlo in locale: `python3 -m http.server` e apri `http://localhost:8000`.

## Organizzatore (host)

Solo l'organizzatore può creare e chiudere le partite, assegnare il campione, togliere scommettitori e azzerare il torneo.
Tutti gli altri possono aggiungersi e scommettere.

1. Appena il sito è online, apri Setup > Organizzatore e crea un PIN (almeno 4 caratteri). Il primo PIN creato vale per tutti, quindi fallo tu per primo.
2. Su ogni altro dispositivo da cui vuoi gestire il torneo, inserisci lo stesso PIN.
3. Se dimentichi il PIN, elimina il documento `meta/host` da Firestore Database nella console Firebase e creane uno nuovo.

Nota: il PIN protegge l'app, non il database. Le regole in `firestore.rules` restano aperte, quindi chi sa usare gli strumenti
per sviluppatori potrebbe aggirarlo. Per una serata tra amici basta.

## Aggiungila alla Home del telefono

Apri il link del sito dal telefono, poi:
- **iPhone (Safari):** tocca Condividi, poi "Aggiungi alla schermata Home".
- **Android (Chrome):** tocca i tre puntini, poi "Installa app" (o "Aggiungi a schermata Home").

L'icona 🍺 apre l'app a schermo intero, senza barra del browser. Serve la connessione per leggere e salvare i dati.

## Squadre

Le 19 squadre sono nell'array `NAMES` all'inizio di `app.js`. Modificalo per cambiare i partecipanti.
Il saldo iniziale è la costante `START`.

## Sicurezza

Le regole in `firestore.rules` permettono a chiunque abbia il link di leggere e scrivere: va bene per una serata tra amici.
A fine torneo elimina il progetto Firebase.

## Struttura

```
index.html          pagina
style.css           stile (chiaro e scuro)
app.js              logica, quote e sincronizzazione
firebase-config.js  dati del tuo progetto Firebase
firestore.rules     regole del database
manifest.webmanifest  nome e icone dell'app installabile
sw.js               service worker (installazione)
icon-*.png, apple-touch-icon.png, favicon.png  icone
```
